#!/bin/sh

echo "请输入我的世界服务端类型（如：vanilla, forge, fabric）："
read server_type
echo "请输入我的世界服务端版本（如：1.16.5）："
read server_version
echo "请输入Java堆内存大小（如：1024M）："
read java_memory

case $server_type in
    vanilla)
        download_url="https://launcher.mojang.com/v1/objects/c8f83c5655308435b3dcf03c06d9fe8740a77469/server.jar"
        ;;
    forge)
        download_url="https://maven.minecraftforge.net/net/minecraftforge/forge/$server_version-36.2.34/forge-$server_version-36.2.34-installer.jar"
        ;;
    fabric)
        download_url="https://maven.fabricmc.net/net/fabricmc/fabric-installer/$server_version/fabric-installer-$server_version.jar"
        ;;
    *)
        echo "不支持的服务端类型，请输入正确的服务端类型（vanilla, forge, fabric）。"
        exit 1
        ;;
esac

echo "正在下载服务端..."
wget -O server.jar $download_url

if [ $? -ne 0 ]; then
    echo "下载失败，请检查服务端类型和版本是否正确。"
    exit 1
fi

echo "下载完成，正在启动服务器..."
java -Xmx$java_memory -Xms$java_memory -jar server.jar nogui
